"""
eda_analysis.py
Reproducible EDA for CodeAlpha_WineEDA project.
Run: python scripts/eda_analysis.py
Produces plots in plots/ and summary CSV in report/
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import ttest_ind
import statsmodels.api as sm
from pandas.plotting import scatter_matrix
from pathlib import Path
p = Path(__file__).resolve().parents[1]

# Load data
df = pd.read_csv(p/"data"/"wine_data.csv")

# Basic info
print("Shape:", df.shape)
print("Dtypes:\\n", df.dtypes)
print("Missing values:\\n", df.isnull().sum())

# Summary statistics
summary = df.describe().T
summary.to_csv(p/"report"/"summary_statistics.csv")

# Correlation matrix
corr = df.corr()
corr.to_csv(p/"report"/"correlation_matrix.csv")

# Histograms
num_cols = df.select_dtypes(include=np.number).columns.tolist()
num_cols.remove('target')
plt.figure(figsize=(12,8))
df[num_cols].hist(bins=20, figsize=(12,10))
plt.suptitle("Histograms")
plt.savefig(p/"plots"/"histograms_repro.png", bbox_inches='tight', dpi=150)
plt.close('all')

# Boxplots (first 10)
plt.figure(figsize=(12,6))
df[num_cols[:10]].boxplot(rot=90)
plt.title("Boxplots (first 10 numeric features)")
plt.savefig(p/"plots"/"boxplots_repro.png", bbox_inches='tight', dpi=150)
plt.close('all')

# Correlation heatmap (matplotlib)
plt.figure(figsize=(10,9))
plt.imshow(corr, interpolation='nearest', aspect='auto')
plt.xticks(range(len(corr.columns)), corr.columns, rotation=90, fontsize=8)
plt.yticks(range(len(corr.index)), corr.index, fontsize=8)
plt.colorbar()
plt.title("Correlation matrix (heatmap)")
plt.savefig(p/"plots"/"corr_heatmap_repro.png", bbox_inches='tight', dpi=150)
plt.close('all')

# Scatter matrix for selected columns
cols = ['alcohol','malic_acid','ash','alcalinity_of_ash','magnesium','proline','target']
scatter_matrix(df[cols], alpha=0.6, diagonal='hist', figsize=(10,10))
plt.suptitle("Scatter matrix (selected)")
plt.savefig(p/"plots"/"scatter_matrix_repro.png", bbox_inches='tight', dpi=150)
plt.close('all')

# T-test: alcohol between class 0 and class 1
group0 = df[df['target']==0]['alcohol']
group1 = df[df['target']==1]['alcohol']
tstat, pval = ttest_ind(group0, group1, equal_var=False)
with open(p/"report"/"t_test_alcohol.txt","w") as fh:
    fh.write(f"t_statistic={tstat}\\np_value={pval}\\nmean0={group0.mean()}\\nmean1={group1.mean()}\\n")

# Regression (alcohol ~ malic_acid + ash)
X = df[['malic_acid','ash']]
y = df['alcohol']
Xc = sm.add_constant(X)
model = sm.OLS(y, Xc).fit()
with open(p/"report"/"regression_summary.txt","w") as fh:
    fh.write(model.summary().as_text())

# Outlier detection (IQR)
Q1 = df[num_cols].quantile(0.25)
Q3 = df[num_cols].quantile(0.75)
IQR = Q3 - Q1
outlier_mask = ((df[num_cols] < (Q1 - 1.5 * IQR)) | (df[num_cols] > (Q3 + 1.5 * IQR)))
outlier_counts = outlier_mask.sum()
outlier_counts.to_csv(p/"report"/"outlier_counts.csv")

print("EDA complete. Artifacts saved to plots/ and report/")

# CodeAlpha_WineEDA

**Repository name (for GitHub):** `CodeAlpha_WineEDA`

This project is an end-to-end Exploratory Data Analysis (EDA) on the public Wine dataset (sklearn).
It is prepared to satisfy CodeAlpha internship submission requirements: upload source code to GitHub,
post a video explanation on LinkedIn, and submit via the Submission Form.

## Contents
- `data/wine_data.csv` — dataset used.
- `scripts/eda_analysis.py` — reproducible script to run the analysis and regenerate plots/reports.
- `plots/` — generated plot images (histograms, boxplots, correlation heatmap, scatter matrix).
- `report/` — CSV/text summaries (summary statistics, correlation matrix, t-test, regression summary, outlier counts).
- `requirements.txt` — Python packages required.
- `README.md` — this file.
- `report/EDA_report.md` — human-readable project report with findings and upload instructions.

## How to run
1. Create a virtual environment (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate  # on Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. Run the EDA script:
   ```bash
   python scripts/eda_analysis.py
   ```
3. Inspect `plots/` and `report/` for outputs.

---
**Prepared for:** CodeAlpha internship submission checklist.

# EDA Report — CodeAlpha_WineEDA

## Project overview
Performed exploratory data analysis on the Wine dataset (sklearn). The goal is to discover structure, trends, anomalies, test hypotheses, and prepare materials for submission.

## Key questions asked
- What are the main variables and their distributions?
- Are there missing values or duplicates?
- Which variables are correlated?
- Do different wine classes have different alcohol content?
- Are there outliers or anomalous observations?

## Dataset
- Rows: 178
- Columns: 14
- No missing values. No duplicates.

## Main findings (summary)
- Mean alcohol: 13.0006, std: 0.8118
- T-test (alcohol between class 0 and class 1): see `report/t_test_alcohol.txt`
- Regression (alcohol ~ malic_acid + ash): short summary in `report/regression_summary.txt`.
- Correlation matrix saved in `report/correlation_matrix.csv` — inspect strong correlations visually in `plots/corr_heatmap.png`.
- Outliers detected per feature saved in `report/outlier_counts.csv`.

## Files to upload to GitHub (suggested)
- All files in this repo. Use repository name: `CodeAlpha_WineEDA`

## Suggested LinkedIn post text (copy & paste)
> Excited to share my internship project for @CodeAlpha — Exploratory Data Analysis on the Wine dataset. I analyzed variable distributions, correlations, ran hypothesis tests, and produced visualizations. Repository: `github.com/<your-username>/CodeAlpha_WineEDA`. Full project walkthrough video: [link].

## Video script checklist
1. Short intro (name, internship with CodeAlpha, project title). (10–15s)
2. Show GitHub repo and files. (15s)
3. Explain main questions and methodology (EDA steps). (30s)
4. Show key plots (histograms, heatmap, boxplots). (30s)
5. Summarize findings and next steps. (15–20s)
6. Provide GitHub repo link on-screen and mention Submission Form done. (10s)

## Submission checklist (for Submission Form)
- [ ] GitHub repo `CodeAlpha_WineEDA` uploaded with full source code.
- [ ] LinkedIn post tagging `@CodeAlpha` with repo link.
- [ ] Video explanation posted on LinkedIn with repo link.
- [ ] Submission Form completed (attach repo link).

---
*End of report.*

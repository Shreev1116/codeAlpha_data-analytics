import requests
from bs4 import BeautifulSoup
import csv

def scrape_indeed(job_title, location):
    job_title = job_title.replace(" ", "+")
    location = location.replace(" ", "+")
    url = f"https://in.indeed.com/jobs?q={job_title}&l={location}"

    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "html.parser")

    job_cards = soup.find_all("div", class_="jobsearch-SerpJobCard")

    results = []
    for job in job_cards:
        title = job.find("a").text.strip() if job.find("a") else "N/A"
        company = job.find("span", class_="company").text.strip() if job.find("span", class_="company") else "N/A"
        location = job.find("div", class_="recJobLoc")["data-rc-loc"] if job.find("div", class_="recJobLoc") else "N/A"

        results.append([title, company, location])

    with open("results.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Job Title", "Company", "Location"])
        writer.writerows(results)

    print("Scraping Complete. Results saved to results.csv")

if __name__ == "__main__":
    scrape_indeed("python developer", "india")

# CodeAlpha Indeed Job Scraper

This project scrapes job listings from Indeed.

## How to Run

1. Install required packages:
```
pip install -r requirements.txt
```

2. Run the scraper:
```
python scraper.py
```

3. Output is saved to **results.csv**
